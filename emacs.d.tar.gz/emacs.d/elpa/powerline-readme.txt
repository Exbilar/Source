Powerline is a library for customizing the mode-line that is based on the Vim
Powerline. A collection of predefined themes comes with the package.
